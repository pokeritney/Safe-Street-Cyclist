============Below is a draft for TA, feel free to add===========
1. Navigate to the project directory, 
In the command shell, run the following command
$ python -m http.server

2. This will set up a local host in your computer
A local server address will appear in the shell, copy that address and paste it into your browser
In case no address is displayed, enter http://0.0.0.0:8000/index.html
Hit okay, you are then in Safe Street for Cyclist's interface


=========Below is for team 64 members===========
1. Use python to set up local host

-Static - All static files
        -css style
        -res: data files to load in html file
-Lib - d3 file folder