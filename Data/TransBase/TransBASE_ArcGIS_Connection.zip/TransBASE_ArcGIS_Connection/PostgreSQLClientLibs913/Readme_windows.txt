The following libraries make up the Windows PostgreSQL 9.1.3 client libraries.

They are used when an ArcGIS for Server, ArcGIS Engine, ArcGIS for Desktop, or ArcGIS Runtime client connects directly to an enterprise geodatabase on PostgreSQL or 
PostgreSQL database.

Please unzip the file and place the libraries in the bin folder of the client application that you would like to use to connect to PostgreSQL 9.0.5.



Windows 32-bit PostgreSQL 9.1.3 Client Libraries:
Libpq.dll
Libeay32.dll
Libintl-8.dll
Ssleay32.dll
Libiconv-2.dll

Place these files in the bin folders of the following Windows 32-bit Esri client applications:
ArcGIS for Desktop: C:\Program Files\ArcGIS\Desktop10.1\bin
ArcGIS Engine: C:\Program Files\ArcGIS\Engine10.1\bin



Windows 64-bit PostgreSQL 9.1.3 Client Libraries:
Libpq.dll
Libeay32.dll
Libintl.dll
Ssleay32.dll
Libiconv-2.dll

Place these files in the bin folders of the following Windows 64-bit Esri client applications:
ArcGIS for Server: C:\Program Files\ArcGIS\Server\bin


ArcGIS Runtime is being distributed as part of an SDK installation, either Java, WPF or Qt, each of these SDKs contains bin folders for both 32bit 
and 64bit environments. A deployment of an application created with one of these SDK environments will also result in a bin folder. Please place 
the PostgreSQL client libraries in the bin folder of the application through which you would like to connect to the PostgreSQL database cluster, either 
in the testing environment of the SDK installation or in the bin folder of the deployed application.


Note: Please be careful when copying the PostgeSQL client libraries to 32-bit and 64-bit locations; for the most part, the files have the same or similar name. 
If a 32-bit file is placed in a 64-bit location, the intended application may fail to start. 

