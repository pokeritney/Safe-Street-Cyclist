# Core DMC Web Stack platform

Project containes two branches:
- **soufun** - Implementation using soufun rental listing data set with heat map and interpolation (ML) analysis using overlay grid
- **weibo** - Implementation using weibo social media data set with graph analysis, click events, and animated transitions.
